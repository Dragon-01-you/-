class ChatSystem {
    constructor() {
        this.chatMessages = document.getElementById('chatMessages');
        this.messageInput = document.getElementById('messageInput');
        this.sendButton = document.getElementById('sendButton');
        this.loadingIndicator = document.getElementById('loadingIndicator');
        this.errorModal = document.getElementById('errorModal');
        
        this.isLoading = false;
        this.messageId = 0;
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.autoResizeInput();
        this.focusInput();
    }
    
    bindEvents() {
        // 发送按钮点击事件
        this.sendButton.addEventListener('click', () => this.sendMessage());
        
        // 输入框键盘事件
        this.messageInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // 输入框自动调整大小
        this.messageInput.addEventListener('input', () => this.autoResizeInput());
        
        // 错误模态框关闭事件
        document.getElementById('errorClose').addEventListener('click', () => {
            this.hideErrorModal();
        });
        
        // 点击模态框背景关闭
        this.errorModal.addEventListener('click', (e) => {
            if (e.target === this.errorModal) {
                this.hideErrorModal();
            }
        });
        
        // ESC键关闭模态框
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.errorModal.classList.contains('show')) {
                this.hideErrorModal();
            }
        });
    }
    
    autoResizeInput() {
        const input = this.messageInput;
        input.style.height = 'auto';
        const newHeight = Math.min(input.scrollHeight, 120); // 最大高度120px
        input.style.height = newHeight + 'px';
    }
    
    focusInput() {
        this.messageInput.focus();
    }
    
    async sendMessage() {
        const message = this.messageInput.value.trim();
        
        if (!message || this.isLoading) {
            return;
        }
        
        // 清空输入框
        this.messageInput.value = '';
        this.autoResizeInput();
        
        // 添加用户消息
        this.addMessage(message, 'user');
        
        // 显示加载状态
        this.showLoading();
        
        try {
            // 模拟API调用（实际使用时替换为真实API）
            const response = await this.simulateApiCall(message);
            this.hideLoading();
            this.addMessage(response, 'ai');
        } catch (error) {
            this.hideLoading();
            this.showError('网络连接出现问题，请稍后重试。');
        }
    }
    
    addMessage(content, type) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}-message`;
        messageDiv.style.opacity = '0';
        
        const time = this.getCurrentTime();
        
        messageDiv.innerHTML = `
            <div class="message-content">
                <div class="message-text">
                    ${this.formatMessageContent(content)}
                </div>
                <div class="message-time">${time}</div>
            </div>
        `;
        
        this.chatMessages.appendChild(messageDiv);
        
        // 使用Anime.js实现动画
        anime({
            targets: messageDiv,
            opacity: [0, 1],
            translateY: [20, 0],
            duration: 300,
            easing: 'easeOutQuad'
        });
        
        // 滚动到底部
        this.scrollToBottom();
    }
    
    formatMessageContent(content) {
        // 如果是字符串，转换为段落
        if (typeof content === 'string') {
            return content.split('\n').map(p => `<p>${p}</p>`).join('');
        }
        
        // 如果是对象，根据类型格式化
        if (typeof content === 'object') {
            let html = '';
            
            if (content.answer) {
                html += content.answer.split('\n').map(p => `<p>${p}</p>`).join('');
            }
            
            if (content.sources && content.sources.length > 0) {
                html += '<div class="message-sources">';
                html += '<p><strong>相关信息来源：</strong></p>';
                html += '<ul>';
                content.sources.forEach(source => {
                    html += `<li><a href="${source.url}" target="_blank">${source.title}</a></li>`;
                });
                html += '</ul>';
                html += '</div>';
            }
            
            return html || '<p>暂无相关信息</p>';
        }
        
        return `<p>${content}</p>`;
    }
    
    showLoading() {
        this.isLoading = true;
        this.sendButton.disabled = true;
        this.loadingIndicator.style.display = 'flex';
        
        // 动画显示加载指示器
        anime({
            targets: this.loadingIndicator,
            opacity: [0, 1],
            translateY: [-10, 0],
            duration: 200,
            easing: 'easeOutQuad'
        });
        
        this.scrollToBottom();
    }
    
    hideLoading() {
        this.isLoading = false;
        this.sendButton.disabled = false;
        
        // 动画隐藏加载指示器
        anime({
            targets: this.loadingIndicator,
            opacity: [1, 0],
            translateY: [0, -10],
            duration: 200,
            easing: 'easeInQuad',
            complete: () => {
                this.loadingIndicator.style.display = 'none';
            }
        });
    }
    
    showError(message) {
        document.getElementById('errorMessage').textContent = message;
        this.errorModal.classList.add('show');
        
        // 动画显示模态框
        anime({
            targets: this.errorModal,
            opacity: [0, 1],
            duration: 300,
            easing: 'easeOutQuad'
        });
    }
    
    hideErrorModal() {
        anime({
            targets: this.errorModal,
            opacity: [1, 0],
            duration: 200,
            easing: 'easeInQuad',
            complete: () => {
                this.errorModal.classList.remove('show');
            }
        });
    }
    
    scrollToBottom() {
        // 延迟滚动以确保DOM已更新
        setTimeout(() => {
            this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
        }, 100);
    }
    
    getCurrentTime() {
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        return `${hours}:${minutes}`;
    }
    
    // 模拟API调用（实际使用时替换为真实API）
    async simulateApiCall(message) {
        // 模拟网络延迟
        await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 1000));
        
        // 模拟随机错误（5%概率）
        if (Math.random() < 0.05) {
            throw new Error('Network error');
        }
        
        // 根据关键词返回不同的回答
        const lowerMessage = message.toLowerCase();
        
        if (lowerMessage.includes('招生') || lowerMessage.includes('录取')) {
            return {
                answer: `关于招生信息：
江西工业工程职业技术学院2024年招生工作已经开始，我们提供多个热门专业供您选择。

招生特色：
• 省级示范性高职院校
• 就业率连续多年保持高位
• 产教融合，校企合作
• 现代化校园设施完善

建议您访问学校招生网站或拨打招生咨询电话获取最新招生政策和录取分数线信息。`,
                sources: [
                    { title: '招生信息网', url: '#' },
                    { title: '专业介绍', url: '#' }
                ]
            };
        }
        
        if (lowerMessage.includes('专业') || lowerMessage.includes('专业设置')) {
            return {
                answer: `学校专业设置：
江西工业工程职业技术学院设有多个二级学院，涵盖工科、管理、艺术等多个领域。

主要专业方向：
• 工程技术类：机械设计、电气自动化、建筑工程等
• 信息技术类：计算机应用、软件技术、大数据技术等
• 经济管理类：会计、市场营销、物流管理等
• 艺术设计类：环境艺术设计、数字媒体艺术设计等

每个专业都配备专业的师资队伍和先进的实训设备，确保学生能够掌握实用技能。`,
                sources: [
                    { title: '专业目录', url: '#' },
                    { title: '课程介绍', url: '#' }
                ]
            };
        }
        
        if (lowerMessage.includes('就业') || lowerMessage.includes('工作')) {
            return {
                answer: `就业情况：
江西工业工程职业技术学院毕业生就业率连续9年高于全省高校平均水平，就业质量稳步提升。

就业优势：
• 与众多知名企业建立长期合作关系
• 完善的就业指导服务体系
• 辐射京津、长三角、珠三角等经济发达地区的就业网络
• 毕业生专业技能扎实，综合素质过硬

学校每年举办多场大型招聘会，为学生和企业提供面对面交流的平台。`,
                sources: [
                    { title: '就业信息网', url: '#' },
                    { title: '校企合作', url: '#' }
                ]
            };
        }
        
        if (lowerMessage.includes('校园') || lowerMessage.includes('环境')) {
            return {
                answer: `校园环境：
江西工业工程职业技术学院新校园占地面积630余亩，位于萍乡经济技术开发区玉湖湖畔，依山傍水，风景秀丽。

校园特色：
• 现代化教学楼、实训楼、图书馆等设施完善
• 心月湖、逅龙山等自然景观优美
• 学生公寓、食堂、体育馆等生活设施齐全
• 智慧校园建设先进，网络覆盖全面

校园内绿树成荫，环境优雅，是学习和生活的理想场所。`,
                sources: [
                    { title: '校园风光', url: '#' },
                    { title: '学校简介', url: '#' }
                ]
            };
        }
        
        if (lowerMessage.includes('学费') || lowerMessage.includes('费用')) {
            return {
                answer: `学费标准：
江西工业工程职业技术学院严格按照江西省教育厅和物价部门的规定收取学费。

学费情况：
• 普通专业：每年5000-6000元
• 艺术类专业：每年8000-10000元
• 住宿费：每年800-1200元（根据宿舍条件）

学校还设有完善的奖助学金体系，包括国家奖学金、励志奖学金、助学金等，帮助家庭经济困难学生顺利完成学业。

具体收费标准以当年招生简章为准。`,
                sources: [
                    { title: '收费标准', url: '#' },
                    { title: '奖助学金', url: '#' }
                ]
            };
        }
        
        // 默认回答
        return {
            answer: `感谢您的提问！

我是江西工业工程职业技术学院的智能问答助手，可以为您提供以下方面的信息：

• 招生政策和录取信息
• 专业设置和课程介绍  
• 就业情况和校企合作
• 校园环境和学习生活
• 学费标准和奖助学金
• 其他学校相关信息

请您提供更具体的问题，我会为您详细解答。`,
            sources: [
                { title: '学校官网', url: '#' },
                { title: '联系我们', url: '#' }
            ]
        };
    }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
    new ChatSystem();
});

// 防止页面刷新时丢失焦点
document.addEventListener('visibilitychange', () => {
    if (!document.hidden) {
        setTimeout(() => {
            document.getElementById('messageInput')?.focus();
        }, 100);
    }
});